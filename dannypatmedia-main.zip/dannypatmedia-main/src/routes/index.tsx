import { createFileRoute } from "@tanstack/react-router";
import heroAsset from "@/assets/dannypat-hero.jpg.asset.json";
const hero = heroAsset.url;
import workMugs from "@/assets/work-mugs.jpg";
import workJerseysAsset from "@/assets/work-jerseys.jpg.asset.json";
const workJerseys = workJerseysAsset.url;
import workPhotoAsset from "@/assets/work-photoshoot.jpg.asset.json";
const workPhoto = workPhotoAsset.url;
import workLarge from "@/assets/work-largeformat.jpg";
import logoAsset from "@/assets/dannypat-logo.jpg.asset.json";
const logo = logoAsset.url;
import {
  Shirt, Smartphone, Printer, Trophy, Image as ImageIcon, Camera,
  Coffee, IdCard, Layers, Frame, Phone, MessageCircle, MapPin, ArrowRight, Sparkles,
} from "lucide-react";

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: "DannyPat Media — Printing Services & Photoshoot" },
      { name: "description", content: "Custom t-shirts, mugs, phone covers, ID cards, jerseys, large format printing and photoshoots in Ofoase, Social Center." },
    ],
  }),
  component: Home,
});

const CALL = "tel:+233556751762";
const WHATSAPP = "https://wa.me/233247700724";

const services = [
  { icon: Shirt, title: "T-Shirt Printing", desc: "DTF & sublimation prints that don't crack." },
  { icon: Smartphone, title: "Phone Covers", desc: "Custom cases for every model." },
  { icon: Printer, title: "DTF Printing", desc: "Sharp full-colour transfers on any fabric." },
  { icon: Trophy, title: "Jersey Customize", desc: "Team kits with names, numbers, crests." },
  { icon: ImageIcon, title: "Large Format", desc: "Banners, billboards, roll-ups, stickers." },
  { icon: Camera, title: "Video & Photoshoot", desc: "Studio and event coverage." },
  { icon: Coffee, title: "Magic & White Mugs", desc: "Photo mugs that change with heat." },
  { icon: IdCard, title: "ID Cards & Holders", desc: "Schools, churches, companies." },
  { icon: Layers, title: "Lamination", desc: "Certificates and documents preserved." },
  { icon: Frame, title: "Picture Frames", desc: "Memories printed and framed." },
];

const works = [
  { src: workLarge, label: "Large format" },
  { src: workMugs, label: "Photo mugs & cases" },
  { src: workJerseys, label: "Custom jerseys" },
  { src: workPhoto, label: "Photoshoots" },
];

function Home() {
  return (
    <div
      className="min-h-screen text-foreground relative"
      style={{
        backgroundImage: `url(${hero})`,
        backgroundSize: "cover",
        backgroundPosition: "center top",
        backgroundAttachment: "fixed",
      }}
    >
      {/* Dark overlay so text stays readable */}
      <div className="absolute inset-0 bg-black/70 pointer-events-none" aria-hidden />

      <div className="relative z-10">
        {/* Nav */}
        <header className="sticky top-0 z-40 backdrop-blur-md bg-black/60 border-b border-white/10">
          <div className="mx-auto max-w-6xl px-5 h-16 flex items-center justify-between">
            <a href="#top" className="flex items-center gap-2.5">
              <img src={logo} alt="DannyPat Media" className="h-10 w-auto rounded-lg object-contain" />
            </a>
            <nav className="hidden md:flex items-center gap-8 text-sm text-white/70">
              <a href="#services" className="hover:text-white transition">Services</a>
              <a href="#work" className="hover:text-white transition">Work</a>
              <a href="#contact" className="hover:text-white transition">Contact</a>
            </nav>
            <a href={WHATSAPP} target="_blank" rel="noreferrer" className="inline-flex items-center gap-1.5 rounded-full bg-accent text-accent-foreground px-4 py-2 text-sm font-semibold shadow-soft hover:shadow-glow transition">
              <MessageCircle className="w-4 h-4" /> Order
            </a>
          </div>
        </header>

        {/* Hero */}
        <section id="top" className="relative overflow-hidden">
          <div className="relative mx-auto max-w-6xl px-5 pt-16 pb-24 md:pt-24 md:pb-32 grid md:grid-cols-12 gap-10 items-center">
            <div className="md:col-span-7 text-white">
              <span className="inline-flex items-center gap-2 rounded-full bg-white/10 border border-white/20 px-3 py-1 text-xs font-medium backdrop-blur">
                <Sparkles className="w-3.5 h-3.5 text-accent" /> Ofoase, Social Center
              </span>
              <h1 className="mt-5 font-display text-5xl md:text-7xl font-bold leading-[0.95] text-balance">
                We design.<br />
                We print.<br />
                <span className="text-accent">We deliver.</span>
              </h1>
              <p className="mt-6 max-w-xl text-lg text-white/80">
                From a single mug to a roadside billboard — DannyPat Media turns your idea into something you can hold, wear or hang on a wall.
              </p>
              <div className="mt-8 flex flex-wrap gap-3">
                <a href={WHATSAPP} target="_blank" rel="noreferrer" className="inline-flex items-center gap-2 rounded-full bg-accent text-accent-foreground px-6 py-3 font-semibold shadow-glow hover:translate-y-[-1px] transition">
                  Start an order <ArrowRight className="w-4 h-4" />
                </a>
                <a href="#services" className="inline-flex items-center gap-2 rounded-full bg-white/10 border border-white/25 text-white px-6 py-3 font-semibold hover:bg-white/15 transition">
                  See services
                </a>
              </div>
            </div>
            <div className="md:col-span-5">
              <div className="relative rounded-3xl overflow-hidden shadow-glow ring-1 ring-white/10">
                <img src={hero} alt="DannyPat Media — your premier partner in creative printing and photography" width={720} height={1280} className="w-full h-auto object-contain bg-black/40" />
                <div className="absolute bottom-3 left-3 right-3 flex items-center justify-between rounded-2xl bg-black/80 backdrop-blur px-4 py-3">
                  <div>
                    <div className="text-xs text-white/60">Turnaround</div>
                    <div className="font-display font-bold text-white">Same-day on most jobs</div>
                  </div>
                  <div className="grid place-items-center w-10 h-10 rounded-full bg-accent text-accent-foreground">
                    <Sparkles className="w-5 h-5" />
                  </div>
                </div>
              </div>
            </div>
          </div>
        </section>

        {/* Marquee strip */}
        <div className="border-y border-white/10 bg-black/40 backdrop-blur">
          <div className="mx-auto max-w-6xl px-5 py-4 flex flex-wrap items-center justify-center gap-x-8 gap-y-2 text-xs uppercase tracking-[0.2em] text-white/60">
            <span>DTF Printing</span><span className="text-accent">●</span>
            <span>Magic Mugs</span><span className="text-accent">●</span>
            <span>ID Cards</span><span className="text-accent">●</span>
            <span>Jersey Customize</span><span className="text-accent">●</span>
            <span>Large Format</span><span className="text-accent">●</span>
            <span>Photoshoot</span>
          </div>
        </div>

        {/* Services */}
        <section id="services" className="mx-auto max-w-6xl px-5 py-20 md:py-28">
          <div className="flex items-end justify-between gap-6 flex-wrap">
            <div>
              <div className="text-sm font-semibold text-accent uppercase tracking-widest">Our Services</div>
              <h2 className="mt-2 font-display text-4xl md:text-5xl font-bold text-balance max-w-2xl text-white">
                Everything you need to make your brand visible.
              </h2>
            </div>
            <p className="text-white/70 max-w-sm">Ten production lines under one roof. Bring your file or just an idea — we'll handle the rest.</p>
          </div>

          <div className="mt-12 grid sm:grid-cols-2 lg:grid-cols-3 gap-4">
            {services.map(({ icon: Icon, title, desc }, i) => (
              <article
                key={title}
                className="group relative rounded-2xl bg-black/50 backdrop-blur-md p-6 border border-white/10 shadow-soft hover:shadow-glow hover:-translate-y-1 transition-all duration-300"
              >
                <div className="flex items-start justify-between">
                  <div className="grid place-items-center w-12 h-12 rounded-xl bg-white/5 text-white group-hover:bg-accent group-hover:text-accent-foreground transition-colors">
                    <Icon className="w-6 h-6" />
                  </div>
                  <span className="text-xs font-mono text-white/50">0{i + 1}</span>
                </div>
                <h3 className="mt-5 font-display text-xl font-semibold text-white">{title}</h3>
                <p className="mt-1.5 text-sm text-white/70">{desc}</p>
              </article>
            ))}
          </div>
        </section>

        {/* Work gallery */}
        <section id="work" className="bg-black/40 border-y border-white/10">
          <div className="mx-auto max-w-6xl px-5 py-20 md:py-28">
            <div className="text-sm font-semibold text-accent uppercase tracking-widest">Recent Work</div>
            <h2 className="mt-2 font-display text-4xl md:text-5xl font-bold text-balance max-w-2xl text-white">
              Pieces we've printed, framed and delivered.
            </h2>

            <div className="mt-12 grid md:grid-cols-12 gap-4">
              {works.map((w, i) => (
                <figure
                  key={w.label}
                  className={`relative overflow-hidden rounded-2xl shadow-soft group ${
                    i === 0 ? "md:col-span-7 md:row-span-2 aspect-[4/5] md:aspect-auto md:h-[560px]" :
                    i === 1 ? "md:col-span-5 aspect-square" :
                    i === 2 ? "md:col-span-2 aspect-square md:aspect-auto md:h-[272px]" :
                    "md:col-span-3 aspect-square md:aspect-auto md:h-[272px]"
                  }`}
                >
                  <img src={w.src} alt={w.label} loading="lazy" width={1024} height={1024} className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-700" />
                  <figcaption className="absolute bottom-3 left-3 rounded-full bg-black/80 backdrop-blur px-3 py-1 text-xs font-semibold text-white">
                    {w.label}
                  </figcaption>
                </figure>
              ))}
            </div>
          </div>
        </section>

        {/* Process */}
        <section className="mx-auto max-w-6xl px-5 py-20 md:py-28">
          <div className="grid md:grid-cols-2 gap-12 items-start">
            <div>
              <div className="text-sm font-semibold text-accent uppercase tracking-widest">How it works</div>
              <h2 className="mt-2 font-display text-4xl md:text-5xl font-bold text-balance text-white">
                Three steps from idea to delivery.
              </h2>
              <p className="mt-5 text-white/70 max-w-md">
                Send a message on WhatsApp with your file or idea. We'll quote, design and produce — most jobs leave the shop the same day.
              </p>
              <a href={WHATSAPP} target="_blank" rel="noreferrer" className="mt-8 inline-flex items-center gap-2 rounded-full bg-primary text-primary-foreground px-6 py-3 font-semibold hover:bg-primary/90 transition">
                <MessageCircle className="w-4 h-4" /> Chat on WhatsApp
              </a>
            </div>
            <ol className="space-y-3">
              {[
                ["01", "Tell us what you need", "Share your design, photo, or just describe it. We'll mock it up."],
                ["02", "Approve & we print", "Once you're happy, we send it to press the same day."],
                ["03", "Pick up or delivery", "Collect at Ofoase Social Center or arrange dispatch."],
              ].map(([n, t, d]) => (
                <li key={n} className="flex gap-5 p-5 rounded-2xl bg-black/50 backdrop-blur-md border border-white/10 shadow-soft">
                  <span className="font-display font-bold text-3xl text-accent leading-none">{n}</span>
                  <div>
                    <h3 className="font-display font-semibold text-lg text-white">{t}</h3>
                    <p className="text-sm text-white/70 mt-1">{d}</p>
                  </div>
                </li>
              ))}
            </ol>
          </div>
        </section>

        {/* CTA / Contact */}
        <section id="contact" className="relative overflow-hidden">
          <div className="absolute inset-0 bg-primary/90" aria-hidden />
          <div className="absolute -bottom-40 -left-40 w-[500px] h-[500px] rounded-full bg-accent/30 blur-3xl" aria-hidden />
          <div className="relative mx-auto max-w-6xl px-5 py-20 md:py-28 text-white">
            <div className="grid md:grid-cols-2 gap-12 items-center">
              <div>
                <h2 className="font-display text-4xl md:text-6xl font-bold text-balance leading-[1]">
                  Let's print something <span className="text-accent">unforgettable.</span>
                </h2>
                <p className="mt-5 text-white/80 max-w-md">
                  Visit the shop, give us a call, or message us on WhatsApp. We reply fast.
                </p>
              </div>
              <div className="space-y-3">
                <a href={CALL} className="flex items-center gap-4 rounded-2xl bg-white/10 border border-white/20 backdrop-blur p-5 hover:bg-white/15 transition">
                  <span className="grid place-items-center w-12 h-12 rounded-xl bg-accent text-accent-foreground"><Phone className="w-5 h-5" /></span>
                  <div>
                    <div className="text-xs uppercase tracking-widest text-white/60">Call</div>
                    <div className="font-display font-semibold">055 675 1762 · 025 663 1807</div>
                  </div>
                </a>
                <a href={WHATSAPP} target="_blank" rel="noreferrer" className="flex items-center gap-4 rounded-2xl bg-white/10 border border-white/20 backdrop-blur p-5 hover:bg-white/15 transition">
                  <span className="grid place-items-center w-12 h-12 rounded-xl bg-accent text-accent-foreground"><MessageCircle className="w-5 h-5" /></span>
                  <div>
                    <div className="text-xs uppercase tracking-widest text-white/60">WhatsApp</div>
                    <div className="font-display font-semibold">024 770 0724</div>
                  </div>
                </a>
                <div className="flex items-center gap-4 rounded-2xl bg-white/10 border border-white/20 backdrop-blur p-5">
                  <span className="grid place-items-center w-12 h-12 rounded-xl bg-accent text-accent-foreground"><MapPin className="w-5 h-5" /></span>
                  <div>
                    <div className="text-xs uppercase tracking-widest text-white/60">Visit</div>
                    <div className="font-display font-semibold">Ofoase, Social Center</div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </section>

        <footer className="border-t border-white/10 bg-black/60">
          <div className="mx-auto max-w-6xl px-5 py-8 flex flex-wrap items-center justify-between gap-3 text-sm text-white/60">
            <div className="flex items-center gap-2">
              <span className="grid place-items-center w-7 h-7 rounded-md bg-primary text-primary-foreground font-display font-bold text-xs">DP</span>
              <span>© {new Date().getFullYear()} DannyPat Media. All rights reserved.</span>
            </div>
            <span>We design · We print · We deliver quality works.</span>
          </div>
        </footer>
      </div>
    </div>
  );
}
